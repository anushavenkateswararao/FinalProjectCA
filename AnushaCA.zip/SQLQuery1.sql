﻿select * from aspnetusers
select * from AspNetUserRoles
select * from AspNetUserLogins