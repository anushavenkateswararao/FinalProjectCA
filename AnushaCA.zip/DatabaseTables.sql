 
 
use Training_12DecMumbai 
 
create schema CollegeAdmini
go
--------------------DepartmentTable-------------------------
Create Table CollegeAdmini.Department(
DeptID int primary key not null identity(1,1),
DeptName varchar(20)
)
select * from CollegeAdmini.Department

insert into CollegeAdmini.Department(deptname) values('IT');

--------------------StudentTable-------------------------
create table CollegeAdmini.Student(
StudentID int not null primary key identity(100,1),
StudentName varchar(30),
FatherName varchar(30),
Address varchar(40),
DeptID int Foreign key references CollegeAdmini.Department(DeptID)
)
select * from CollegeAdmini.Student
insert into CollegeAdmini.student(StudentName,Fathername,address,DeptID) values('Ramu','Sri','HYD',1);
--------------------AvailableSeatsTable-------------------------
create table CollegeAdmini.AvlSeats(
seatid int not null primary key identity(100,1),
DeptID int foreign key references CollegeAdmini.Department(DeptID),
TotalSeats int not null,
FilledSeats int not null,
AvailableSeats int not null
)
select * from CollegeAdmini.Student
select * from CollegeAdmini.AvlSeats
select * from CollegeAdmini.Department
insert into CollegeAdmini.AvlSeats(DeptID,TotalSeats,FilledSeats,Availableseats) values(1,120,0,120);

--------------------FeesTable-------------------------
create table CollegeAdmini.Fee(
FeeID int not null primary key identity(12345,1),
Amount money,
Paid money,
Balance money,
StudentID int foreign key references CollegeAdmini.Student(StudentID),
DeptID int Foreign key references CollegeAdmini.Department(DeptID)
)
select * from CollegeAdmini.Fee
select * from CollegeAdmini.Department
select * from CollegeAdmini.Student
insert into CollegeAdmini.Fee(amount,paid,balance,studentID,DeptID) values(75000,65000,10000,100,1);
--------------------AdmissionTable-------------------------
create table CollegeAdmini.Admission(
AdmissionNumber int not null primary key Identity(1000,1),
StudentName varchar(30),
Gender varchar(10),
check (Gender in ('MALE', 'FEMALE','others')),
DOB date,
FatherName varchar(30),
Occupation varchar(20),
Address varchar(40),
PhoneNumber PhoneNumber,
check (PhoneNumber like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
Course varchar(30),
Caste varchar(10),
FeeID int Foreign key references CollegeAdmini.Fee(FeeId),
DOJ date
)

select * from CollegeAdmini.Fee
select * from CollegeAdmini.Admission
select * from CollegeAdmini.student

insert into CollegeAdmini.Admission(StudentName,Gender,DOB,FatherName,
Occupation,Address,PhoneNumber,Course,Caste,FeeID,DOJ)
 values ('Ramu','male','1996/07/19','Sri','Business',
 'HYD','9652523704','B.tech','Raja',12346,'2015/09/08');
--------------------AdmissionTable-------------------------
create table CollegeAdmini.Staff
(
StaffID int not null primary key identity(10,1),
DeptID int Foreign key references CollegeAdmini.Department(DeptID),
StaffName varchar(20),
PhoneNumber PhoneNumber,
Salary int,
Experience decimal,
Subjects varchar(30),
NameOfInstitute varchar(30),
Address varchar(40)
)

select * from CollegeAdmini.Staff
insert into CollegeAdmini.Staff(DeptID,StaffName,PhoneNumber,Salary,Experience,Subjects,NameOfInstitute,Address) 
                       values(1,'GayathriSarman',9639639637,50000,1,'Drawing','VIT','Bhimavaram');
   

   