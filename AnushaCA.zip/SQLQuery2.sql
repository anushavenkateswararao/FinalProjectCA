﻿select * from AspNetRoles
select * from AspNetUserRoles
select * from AspNetUsers

